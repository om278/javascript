// que 1
arr=[6,4,7,3,6,2,5,1]
function Sort(arr) {
    let x=0;
    while(x < arr.length)
    {
        let i = 0
        while(i < arr.length-x)
         {
            if(arr[i]>arr[i+1]){
               [arr[i], arr[i+1]]=[arr[i+1],arr[i]] 
            }
            i++
        }
        x++
    }
    return arr
}
console.log(Sort(arr));


// que=2
function hcf(num1,num2) {
    while (num2!==0) {
       let tem =num2
       num2=num1%num2
       num1=tem
    }
    return num1
 }
 console.log(hcf(5,10));

// que=4
function rect(n) {
    for (let i = 1; i <=n; i++) {
        str=""
        if (i==1 || i==2 || i==n || i==n-1) {
            for (let j = 1; j <=n; j++) {
                str+="* "
            }
        }
        else {
            for (let j = 1; j <=n; j++) {
                if (j==1 || j==2|| j==n || j==n-1) {
                    str+="* "
                }
                else{
                    str+="  "
                }
            }
        }
        console.log(str)
    }
    }
    rect(7)

